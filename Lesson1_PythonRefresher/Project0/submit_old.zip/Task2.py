"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv

max_duration = 0
with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
    len_call_records = len(calls)
    for i in range(len_call_records):
        caller_ph = calls[i][0]
        receiver_ph = calls[i][1]
        if int(calls[i][3]) > max_duration:
            max_duration = int(calls[i][3])
            interested_ph = calls[0][:2]
print("%s spent the longest time, %2.4f seconds, on the phone during September 2016" % (interested_ph[0], max_duration))

"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during 
September 2016.".
"""
"""
O(N) computations for reading the file and O(N) computations for the for loop. O(1) for the comparison.
Total = O(N) + O(N) + O(1) ~ O(N)
"""

